var F = { exports: {} }, Z = F.exports, q;
function V() {
  return q || (q = 1, (function(n, f) {
    (function(i, l) {
      l(n);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : Z, function(i) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        i.exports = globalThis.browser;
      else {
        const l = "The message port closed before a response was received.", w = (x) => {
          const h = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(h).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class L extends WeakMap {
            constructor(s, t = void 0) {
              super(t), this.createItem = s;
            }
            get(s) {
              return this.has(s) || this.set(s, this.createItem(s)), super.get(s);
            }
          }
          const M = (e) => e && typeof e == "object" && typeof e.then == "function", T = (e, s) => (...t) => {
            x.runtime.lastError ? e.reject(new Error(x.runtime.lastError.message)) : s.singleCallbackArg || t.length <= 1 && s.singleCallbackArg !== !1 ? e.resolve(t[0]) : e.resolve(t);
          }, k = (e) => e == 1 ? "argument" : "arguments", _ = (e, s) => function(g, ...m) {
            if (m.length < s.minArgs)
              throw new Error(`Expected at least ${s.minArgs} ${k(s.minArgs)} for ${e}(), got ${m.length}`);
            if (m.length > s.maxArgs)
              throw new Error(`Expected at most ${s.maxArgs} ${k(s.maxArgs)} for ${e}(), got ${m.length}`);
            return new Promise((c, u) => {
              if (s.fallbackToNoCallback)
                try {
                  g[e](...m, T({
                    resolve: c,
                    reject: u
                  }, s));
                } catch (r) {
                  console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, r), g[e](...m), s.fallbackToNoCallback = !1, s.noCallback = !0, c();
                }
              else s.noCallback ? (g[e](...m), c()) : g[e](...m, T({
                resolve: c,
                reject: u
              }, s));
            });
          }, N = (e, s, t) => new Proxy(s, {
            apply(g, m, c) {
              return t.call(m, e, ...c);
            }
          });
          let p = Function.call.bind(Object.prototype.hasOwnProperty);
          const y = (e, s = {}, t = {}) => {
            let g = /* @__PURE__ */ Object.create(null), m = {
              has(u, r) {
                return r in e || r in g;
              },
              get(u, r, d) {
                if (r in g)
                  return g[r];
                if (!(r in e))
                  return;
                let o = e[r];
                if (typeof o == "function")
                  if (typeof s[r] == "function")
                    o = N(e, e[r], s[r]);
                  else if (p(t, r)) {
                    let E = _(r, t[r]);
                    o = N(e, e[r], E);
                  } else
                    o = o.bind(e);
                else if (typeof o == "object" && o !== null && (p(s, r) || p(t, r)))
                  o = y(o, s[r], t[r]);
                else if (p(t, "*"))
                  o = y(o, s[r], t["*"]);
                else
                  return Object.defineProperty(g, r, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return e[r];
                    },
                    set(E) {
                      e[r] = E;
                    }
                  }), o;
                return g[r] = o, o;
              },
              set(u, r, d, o) {
                return r in g ? g[r] = d : e[r] = d, !0;
              },
              defineProperty(u, r, d) {
                return Reflect.defineProperty(g, r, d);
              },
              deleteProperty(u, r) {
                return Reflect.deleteProperty(g, r);
              }
            }, c = Object.create(e);
            return new Proxy(c, m);
          }, C = (e) => ({
            addListener(s, t, ...g) {
              s.addListener(e.get(t), ...g);
            },
            hasListener(s, t) {
              return s.hasListener(e.get(t));
            },
            removeListener(s, t) {
              s.removeListener(e.get(t));
            }
          }), R = new L((e) => typeof e != "function" ? e : function(t) {
            const g = y(t, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            e(g);
          }), a = new L((e) => typeof e != "function" ? e : function(t, g, m) {
            let c = !1, u, r = new Promise((S) => {
              u = function(b) {
                c = !0, S(b);
              };
            }), d;
            try {
              d = e(t, g, u);
            } catch (S) {
              d = Promise.reject(S);
            }
            const o = d !== !0 && M(d);
            if (d !== !0 && !o && !c)
              return !1;
            const E = (S) => {
              S.then((b) => {
                m(b);
              }, (b) => {
                let O;
                b && (b instanceof Error || typeof b.message == "string") ? O = b.message : O = "An unexpected error occurred", m({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: O
                });
              }).catch((b) => {
                console.error("Failed to send onMessage rejected reply", b);
              });
            };
            return E(o ? d : r), !0;
          }), v = ({
            reject: e,
            resolve: s
          }, t) => {
            x.runtime.lastError ? x.runtime.lastError.message === l ? s() : e(new Error(x.runtime.lastError.message)) : t && t.__mozWebExtensionPolyfillReject__ ? e(new Error(t.message)) : s(t);
          }, $ = (e, s, t, ...g) => {
            if (g.length < s.minArgs)
              throw new Error(`Expected at least ${s.minArgs} ${k(s.minArgs)} for ${e}(), got ${g.length}`);
            if (g.length > s.maxArgs)
              throw new Error(`Expected at most ${s.maxArgs} ${k(s.maxArgs)} for ${e}(), got ${g.length}`);
            return new Promise((m, c) => {
              const u = v.bind(null, {
                resolve: m,
                reject: c
              });
              g.push(u), t.sendMessage(...g);
            });
          }, U = {
            devtools: {
              network: {
                onRequestFinished: C(R)
              }
            },
            runtime: {
              onMessage: C(a),
              onMessageExternal: C(a),
              sendMessage: $.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: $.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, B = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return h.privacy = {
            network: {
              "*": B
            },
            services: {
              "*": B
            },
            websites: {
              "*": B
            }
          }, y(x, U, h);
        };
        i.exports = w(chrome);
      }
    });
  })(F)), F.exports;
}
V();
var P;
(function(n) {
  n.Local = "local", n.Sync = "sync", n.Managed = "managed", n.Session = "session";
})(P || (P = {}));
var j;
(function(n) {
  n.ExtensionPagesOnly = "TRUSTED_CONTEXTS", n.ExtensionPagesAndContentScripts = "TRUSTED_AND_UNTRUSTED_CONTEXTS";
})(j || (j = {}));
const A = globalThis.chrome, D = async (n, f) => {
  const i = (w) => typeof w == "function", l = (w) => (
    // Use ReturnType to infer the return type of the function and check if it's a Promise
    w instanceof Promise
  );
  return i(n) ? (l(n), n(f)) : n;
};
let W = !1;
const z = (n) => {
  if (A && !A.storage[n])
    throw new Error(`"storage" permission in manifest.ts: "storage ${n}" isn't defined`);
}, G = (n, f, i) => {
  var C, R;
  let l = null, w = !1, x = [];
  const h = (i == null ? void 0 : i.storageEnum) ?? P.Local, L = ((C = i == null ? void 0 : i.serialization) == null ? void 0 : C.serialize) ?? ((a) => a), M = ((R = i == null ? void 0 : i.serialization) == null ? void 0 : R.deserialize) ?? ((a) => a);
  W === !1 && h === P.Session && (i == null ? void 0 : i.sessionAccessForContentScripts) === !0 && (z(h), A == null || A.storage[h].setAccessLevel({
    accessLevel: j.ExtensionPagesAndContentScripts
  }).catch((a) => {
    console.error(a), console.error("Please call .setAccessLevel() into different context, like a background script.");
  }), W = !0);
  const T = async () => {
    z(h);
    const a = await (A == null ? void 0 : A.storage[h].get([n]));
    return a ? M(a[n]) ?? f : f;
  }, k = async (a) => {
    w || (l = await T()), l = await D(a, l), await (A == null ? void 0 : A.storage[h].set({ [n]: L(l) })), p();
  }, _ = (a) => (x = [...x, a], () => {
    x = x.filter((v) => v !== a);
  }), N = () => l, p = () => {
    x.forEach((a) => a());
  }, y = async (a) => {
    if (a[n] === void 0)
      return;
    const v = M(a[n].newValue);
    l !== v && (l = await D(v, l), p());
  };
  return T().then((a) => {
    l = a, w = !0, p();
  }), A == null || A.storage[h].onChanged.addListener(y), {
    get: T,
    set: k,
    getSnapshot: N,
    subscribe: _
  };
}, I = G("theme-storage-key", {
  theme: "light",
  isLight: !0
}, {
  storageEnum: P.Local
}), H = {
  ...I,
  toggle: async () => {
    await I.set((n) => {
      const f = n.theme === "light" ? "dark" : "light";
      return {
        theme: f,
        isLight: f === "light"
      };
    });
  }
};
H.get().then((n) => {
  console.log("theme", n);
});
console.log("Background loaded");
console.log("Edit 'chrome-extension/src/background/index.ts' and save to reload.");
chrome.action.onClicked.addListener(async (n) => {
  if (n.id)
    try {
      await chrome.sidePanel.open({ tabId: n.id }), console.log("Side panel opened for tab:", n.id);
    } catch (f) {
      console.error("Failed to open side panel:", f);
    }
});
chrome.runtime.onInstalled.addListener(() => {
  console.log("QuickBridge extension installed"), chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch((n) => {
    console.error("Failed to set panel behavior:", n);
  });
});
